<!-- Click Ctrl+Shift+V -->

[1. 375. Guess Number Higher or Lower II](https://leetcode.com/problems/guess-number-higher-or-lower-ii/description/)



[2. 1130. Minimum Cost Tree From Leaf Values](https://leetcode.com/problems/minimum-cost-tree-from-leaf-values/description/)

[Stack solution of 1130](https://chatgpt.com/share/689ba03c-8854-8003-9a3b-8bd243429cfb)




[3. Matrix Chain Multiplication](https://www.naukri.com/code360/problems/matrix-chain-multiplication_975344?source=youtube&campaign=striver_dp_videos&utm_source=youtube&utm_medium=affiliate&utm_campaign=striver_dp_videos&leftPanelTabValue=PROBLEM)

[Only for revision of MCM](https://chatgpt.com/share/689b9fd7-dd6c-8003-bbc7-7a2bb6f37ae8)


