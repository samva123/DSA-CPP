//877 

// there will be atleast one way  by which alice can win
// that means , we should return true always
//bcz problem is asking is there any way that alice can win 


// so the answer is 

// return true;