#include <iostream>
using namespace std;

void fibcode(int  n){
    

}



int main(){

}