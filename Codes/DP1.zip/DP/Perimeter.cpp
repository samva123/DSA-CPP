#include<iostream>
using namespace std;

int main(){
    int T;
    cin >> T;

    while(T--){
        int n , m ;

        while(n--){
            int x , y;
            cin >> x >> y;
        }

        
    }
}

